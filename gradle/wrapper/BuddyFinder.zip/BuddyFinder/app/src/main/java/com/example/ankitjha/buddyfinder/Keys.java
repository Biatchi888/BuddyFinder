package com.example.ankitjha.buddyfinder;

public class Keys {

    int uid;
    int gid;

    public int getUid() {
        return uid;
    }

    public int getGid() {
        return gid;
    }
}
